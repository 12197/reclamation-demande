<?php
  //connection au serveur

 	 $cnx = @mysqli_connect( "localhost", "root", "" , "reclamationetudiant") ;

  ?>