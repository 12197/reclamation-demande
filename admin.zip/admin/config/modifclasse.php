<?php
session_start();
if (! empty($_SESSION['log']))
{
include("../db/dbcon.php");
 
 
  //récupération des valeurs des champs:
  //nom:
 
 

  $nom = $_POST["nom"] ;

  
  
  $niveau = $_POST["niveau"] ;
  
 

  //récupération de l'identifiant de la personne:
  $id         = $_POST["id"] ;
 
  //création de la requête SQL:
  $sql = "UPDATE classe
            SET 
            	niveau = '$niveau',
            	nom         = '$nom'
		 
           WHERE idclasse = '$id' " ;
 
  //exécution de la requête SQL:
  $requete = mysqli_query($cnx, $sql);
 
 
  //affichage des résultats, pour savoir si la modification a marchée:
  if($requete)
  {
    echo "<script>alert('Classe bien modifier')</script>";
    echo "<script>window.open('../classe_ajout.php#clas','_self')</script>";
  }
  else
  {
    echo "<script>alert('Erreur ')</script>";
    echo "<script>window.open('../classe_ajout.php#clas','_self')</script>";
  }
}
else

{
   header('Location: index.php');
}
    ?>