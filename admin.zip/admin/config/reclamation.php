<?php 
session_start();
include("../db/dbcon.php");

            $matricule = $_POST["matricule"] ;

             $classe    = $_POST["classe"] ;

             $nom       = $_POST["nom"] ;

            $prenom    = $_POST["prenom"] ;

            $typerec   = $_POST["typerec"] ;
            
            $message      = $_POST["message"] ;
           
            $dates     = $_POST["dates"] ;
            
            

  $sql = "INSERT  INTO reclamation (matriculeE , typereclamation , datereclamation , nom , prenom , classeE , message ,reponse)
            VALUES ('$matricule','$typerec','$dates','$nom', '$prenom','$classe', '$message', 'En cours') " ; 
  
  $requete = mysqli_query($cnx,$sql)  ;
 
  
  if($requete)
  {
    echo "<script>window.open('../index2.php','_self')</script>";
  }
  else
  {
    echo("L'insertion a e echoue") ;
  }
?>