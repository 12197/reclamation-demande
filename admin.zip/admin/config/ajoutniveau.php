<?php
session_start();
if (! empty($_SESSION['log']))
{
include("../db/dbcon.php");
 
 

  $nom = $_POST["nom"] ;
  
  


  $sql = "INSERT  INTO niveau (nom)
   VALUES ('$nom') " ; 
  $requete = mysqli_query($cnx,$sql);

  
  if($requete)
    {
      echo "<script>window.open('../niveau_ajout.php#niv','_self')</script>";
    }
  else
    {
      echo("L'insertion a e echoue") ;
    }
}
else

{
   header('Location: index.php');
}
    ?>                                                                                                                       