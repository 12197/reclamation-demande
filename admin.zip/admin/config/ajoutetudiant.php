<?php
session_start();
if (! empty($_SESSION['log']))
{
include("../db/dbcon.php");
 
 


  $matricule = $_POST["matricule"] ;

  $nom = $_POST["nom"] ;

  $prenom = $_POST["prenom"] ;
  
  $niveau = $_POST["niveau"] ;
  
  $classe = $_POST["classe"] ;

  $pass       = $_POST["password"] ;
    $password=md5($pass);



  $sql = "INSERT  INTO etudiant1 (nom, prenom, login, password, classe, niveau)
   VALUES ('$nom','$prenom','$matricule', '$password','$classe', '$niveau') " ; 
  $requete = mysqli_query($cnx,$sql);

  
  if($requete)
    {
      echo "<script>window.open('../etudiant_ajout.php','_self')</script>";
    }
  else
    {
      echo("L'insertion a e echoue") ;
    }
}
else

{
   header('Location: index.php');
}
    ?>                                                                                                                     