<?php
session_start();
if (! empty($_SESSION['log']))
{
include("../db/dbcon.php");
 
 
 

  $nom = $_POST["nom"] ;


  
  $niveau = $_POST["niveau"] ;
 


  $sql = "INSERT  INTO classe (niveau, nom)
   VALUES ('$niveau', '$nom') " ; 
  $requete = mysqli_query($cnx,$sql);

  
  if($requete)
    {
      echo "<script>window.open('../classe_ajout.php','_self')</script>";
    }
  else
    {
      echo("L'insertion a e echoue") ;
    }
}
else

{
   header('Location: index.php');
}
    ?>
                                                                                                                            