<?php
session_start();
if (! empty($_SESSION['log']))
{
include("db/dbcon.php");
 
  //récupération de la variable d'URL,
  //qui va nous permettre de savoir quel enregistrement supprimer:
  $id  = $_GET["idNiveau"] ;
 
  //requête SQL:
  $sql = "DELETE 
            FROM niveau
	    WHERE idniv = ".$id ;
      
  //exécution de la requête:
  $requete = mysqli_query($cnx, $sql) ;
 
  //affichage des résultats, pour savoir si la suppression a marchée:
   if($requete)
  {
    echo "<script>alert('Niveau bien supprimer ')</script>";
    echo "<script>window.open('niveau_ajout.php#niv','_self')</script>";
  }
  else
  {
    echo "<script>alert('Erreur ')</script>";
    echo "<script>window.open('niveau_ajout.php#niv','_self')</script>";
  }
}
else

{
   header('Location: index.php');
}
    ?>