<?php
  
 

session_start();
if (! empty($_SESSION['log']))
{
include("../db/dbcon.php");



  
  $decision = $_POST["decision"] ;
  
  $id = $_POST["id"] ;
  
  

  $sql = "UPDATE demande
            SET     reponse     = '$decision'
           
           WHERE id = '$id' " ;
  
  $requete = mysqli_query($cnx,$sql)  ;
 
  
  if($requete)
  {
    echo "<script>window.open('demandetraite.php#stage','_self')</script>";
  }
  else
  {
    echo("L'insertion a e echoue") ;
  }
  }
  else
{
   header('Location: index.php');
}
?>
